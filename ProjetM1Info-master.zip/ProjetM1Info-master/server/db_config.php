<?php

define("ERREUR", 0);
define("OK",1);

$db_host = 'db614567606.db.1and1.com';
$db_name = 'db614567606';
$db_user = 'dbo614567606';
$db_password = 'ProjetM1Info';


?>
