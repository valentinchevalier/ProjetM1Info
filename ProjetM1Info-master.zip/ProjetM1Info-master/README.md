# ProjetM1Info
Application web sous AngularJS. 

Cette application propose un Workspace dynamique pouvant intégrer différents widgets utilisant de l'OpenData de Toulouse.

Ce projet est réalisé dans le cadre de l'UE Projet de M1 Informatique à l'Université Paul Sabatier.


